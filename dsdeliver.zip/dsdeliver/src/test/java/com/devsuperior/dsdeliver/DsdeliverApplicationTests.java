package com.devsuperior.dsdeliver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsdeliverApplicationTests {

	@Test
	void contextLoads() {
	}

}
